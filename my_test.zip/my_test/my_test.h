#ifndef MY_TEST_H
#define MY_TEST_H

#include <QtWidgets/QMainWindow>
#include "ui_my_test.h"
//#include "login.h"
// #include "zhuyemian.h"
#include <QPushButton>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QPixmap>
#include <QFile>
#include <QImage>
#include <QTimer>
#include <QMessageBox>
#include <QDir>
#include <QDateTime>
#include <QFileDialog>
#include<string>
#include"cv.h"
#include "cxcore.h"
#include "highgui.h"
#include"opencv2/opencv.hpp"
#include<stdio.h>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>  // Gaussian Blur
#include <opencv2/core/core.hpp>        // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/highgui/highgui.hpp>  // OpenCV window I/O
#include "opencv2/objdetect/objdetect.hpp"//人脸识别的接口
using namespace cv;//必须加入,否则无法检找到OPENCV的各个函数
using namespace std;
class my_test : public QMainWindow
{
    Q_OBJECT

public:
    explicit my_test(QWidget *parent = 0);
    ~my_test();



private:
    Ui::my_testClass ui;
    cv::Mat frame;
    cv::Mat yuanshi;
    cv::Mat mimage;
    cv::Mat mimage2;
  //   cv::Mat tupian;
     cv::Mat temp;
    QImage  image;
    QImage  m_img;
  //  std::vector<Rect> faces;
    double rate;
    CascadeClassifier face_cascade;
  //  zhuyemian *zym=new zhuyemian;
    string face_cascade_name = "/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_alt.xml";
 //   login *login1=new login;
//    my_test *zhuce1=new my_test;
public:
    //QPushButton *capture_butn;
    //QPushButton *save_butn;
    //QPushButton *exit_butn;
    //QCamera *camera;
    //QCameraViewfinder *view_finder;
    //QCameraImageCapture *camera_image_capture;
    static int testvalue;
    QTimer *timer;
    cv::VideoCapture capture;
    QImage qimage;  //q开头表示Qt的图像格式
   // cv::Mat cvframe;
     QImage qImg;
      QImage qImg2;
      int savetupian=0;
      std::vector<Rect> faces;
    void m_Initialdisplaylabel();
signals:
    void m_sizechanged();
public slots:
    void captureImage();
    void saveImage();
    void close();
    void displayImage(QImage);
    void m_adjustViewfiderSize();
    void m_openImage();
    void nextFrame();
protected:
    void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;
};
#endif // MY_TEST_H
