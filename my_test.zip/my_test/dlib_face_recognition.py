def dlib_face_recognition():
	import numpy as np
	import face_recognition
	import os  
	from skimage import transform as tf  
	from PIL import Image, ImageDraw
	import sklearn
	import sklearn.metrics.pairwise as pw 
	import threading  
	from time import ctime,sleep  
	import time  
	import matplotlib.pyplot as plt  
	import skimage  
	import sys
	import skimage.io as io
	from skimage import data_dir
	i=0
	k=0
	g=0
	str='/home/hanlifu/my_test/my_test/reg_image' + '/*.jpg'
	coll = io.ImageCollection(str)
	print(len(coll))
	i=len(coll)
	print i
	t1=time.clock()
	for m in range(1,i+1): 
	     zhucepath = '%s%s%s%d%s'%('/home/hanlifu/my_test/my_test/reg_image', '/', 'user',m,'.jpg')
	     # zhucepath='/home/hanlifu/my_test/my_test/reg_image'
	     shibiepath='/home/hanlifu/my_test/my_test/rec_image/test1.jpg'
	     reg_path=zhucepath
	     rec_path=shibiepath
	     word1=reg_path.split('\n')
	     word2=rec_path.split('\n')
	     mypicture=word1[0]
	     unknownpicture=word2[0]
	     picture_of_me = face_recognition.load_image_file(mypicture)
	     my_face_encoding = face_recognition.face_encodings(picture_of_me)[0]
	     unknown_picture = face_recognition.load_image_file(unknownpicture)
	     unknown_face_encoding = face_recognition.face_encodings(unknown_picture)[0]
	     results = face_recognition.compare_faces([my_face_encoding], unknown_face_encoding)
	     if results[0] == True:
	      break
	if results[0] == True:
	 print ("younidetupian")
	 g=1
	else:
	 print("meiyounidetupian")
	 g=0
	t2=time.clock()
	print t2-t1
	return g

  
