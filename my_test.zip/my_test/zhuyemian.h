#ifndef ZHUYEMIAN_H
#define ZHUYEMIAN_H

#include <QDialog>
#include "ui_zhuyemian.h"
#include "my_test.h"
#include"login.h"
#include"renlianrenzheng.h"
namespace Ui {
class zhuyemian;
}

class zhuyemian : public QDialog
{
    Q_OBJECT

public:
    explicit zhuyemian(QWidget *parent = 0);
    ~zhuyemian();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::zhuyemian *ui;
     my_test *zhuce=new my_test;
     login   *zhuceyanzheng=new login;
     renlianrenzheng *renzheng=new renlianrenzheng;
};

#endif // ZHUYEMIAN_H
