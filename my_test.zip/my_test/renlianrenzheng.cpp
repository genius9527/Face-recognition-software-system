#include "login.h"
#include "renlianrenzheng.h"
#include "ui_renlianrenzheng.h"
#include<Python.h>
#include <iostream>
#include<QString>
#include <opencv2/imgproc/imgproc.hpp>  // Gaussian Blur
#include <opencv2/core/core.hpp>        // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/highgui/highgui.hpp>  // OpenCV window I/O
#include "opencv2/objdetect/objdetect.hpp"//???????????
#include<QFile>
#include<QDir>
int renzhengkaishi=0;
// extern QString usernumber;
using namespace cv;//????????,????????????OPENCV?????????
using namespace std;
string window_name3 = "renlianrenzheng";
int renlianrenzheng::testvalue=1;
renlianrenzheng::renlianrenzheng(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::renlianrenzheng)
{
    ui->setupUi(this);
    // connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(close()));
}

renlianrenzheng::~renlianrenzheng()
{
    delete ui;
}

void renlianrenzheng::on_pushButton_2_clicked()
{
    this->hide();
    capture.release();
}

double renlianrenzheng::on_pushButton_clicked()
{   clock_t t1, t2;
    float shijian=0;
    QFile file1("/home/hanlifu/my_test/my_test/rec_image/test1.jpg");
    if(!file1.open(QIODevice::ReadOnly)) {
     //   qDebug()<<"Can't open the file!"<<endl;
     QMessageBox::about(NULL, "warning", "请先去补充认证集");
        return -1;
    }
      t1 = clock();
    Py_Initialize();    // 初始化
// PyObject* moduleName = PyString_FromString("xincaffetiqutezheng"); //模块名，不是文件名
  PyObject* moduleName = PyString_FromString("dlib_face_recognition");
        PyObject* pModule = PyImport_Import(moduleName);
//  PyObject* pv = PyObject_GetAttrString(pModule, "renlianbidui");
 PyObject* pv = PyObject_GetAttrString(pModule, "dlib_face_recognition");
   //      QString path="/home/hanlifu/my_test/my_test/reg_image/test1.jpg";
      PyObject* args = PyTuple_New(1);   // 1个参数
    //   PyObject* args = PyTuple_New(0);   // 1个参数
   //     PyObject* arg1 = Py_BuildValue("s", "/home/hanlifu/my_test/my_test/reg_image/test1.jpg");
         PyObject* arg1= Py_BuildValue("s", "/home/hanlifu/my_test/my_test/rec_image/test1.jpg");
            PyTuple_SetItem(args, 0, arg1);
  //          PyTuple_SetItem(args, 1, arg2);
          PyObject* pRet = PyObject_CallObject(pv, args);
            double result;
            PyArg_Parse(pRet , "d", &result);
       //     QString s = QString::number (result, 10);
        //   if(result>0.62)
        result=1-result;
            ui->label_2->setText(QString::number(result));
            if(result>0.62)
            ui->label_5->setText("注册集有你，通过");
           else
           ui->label_5->setText("別想浑水摸鱼，不通过");
           t2 = clock();
        shijian=((t2-t1)*1.0)/1000000;
          Py_Finalize();
           ui->label_7->setText(QString::number(shijian));
}

void renlianrenzheng::on_pushButton_3_clicked()
{  // qDebug()<<usernumber<<endl;
    capture.release();
    QString str;
        QString m_imagefile;
        face_cascade.load(face_cascade_name);
        vector<Rect> faces2;
        m_imagefile = QFileDialog::getOpenFileName(this, tr("tupianrenlianjiance"), "",
            tr("Image(*.png *.bmp *.jpg)"));
        std::string str1 = m_imagefile.toStdString();
        mimage=imread(str1);
        temp=imread(str1);
      //  if (m_imagefile.isEmpty())
      //      return;
      //  else{

          //  QImage *m_img = new QImage;
          //  if (!(m_img.load(m_imagefile)))
        //    {
         //       QMessageBox::information(this, tr("??????????"), tr("??????????!"));
               // delete m_img;
         //       return;
        //    }
         //   mimage = cv::Mat(m_img.height(), m_img.width(), CV_8UC3, (void*)m_img.constBits(), m_img.bytesPerLine());
                  //  cv::cvtColor(mimage, mimage, CV_BGR2RGB);

            Mat gray;
            cvtColor(temp,gray,CV_BGR2GRAY);
            equalizeHist(gray,gray);
             //   cvtColor(mimage,gray,CV_BGR2GRAY); //×ŞťťłÉťŇśČÍźŁŹŇňÎŞharrĚŘŐ÷´ÓťŇśČÍźÖĐĚáČĄ
            //    equalizeHist(gray,gray);  //Öąˇ˝ÍźžůşâĐĐ

                 face_cascade.detectMultiScale(mimage, faces2, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
             //   face_cascade.detectMultiScale(gray,faces2,1.1,3,0,Size(10,10),Size(100,100));
                for(vector<Rect>::const_iterator iter=faces2.begin();iter!=faces2.end();iter++)
                {
                    rectangle(mimage,*iter,Scalar(0,0,255),2,8); //ť­łöÁł˛żžŘĐÎ
                }
               // cv::cvtColor(mimage,mimage,CV_BGR2RGB);
              //  qImg2 =QImage((const unsigned char*)(mimage.data),
                  //          mimage.cols, mimage.rows,
                 //           mimage.cols*mimage.channels(),
                 //           QImage::Format_RGB888);
                 imshow(window_name3,mimage);
                if(faces2.size()>0)
              { QString sourceDir=m_imagefile;
                QString m_imagename = "/home/hanlifu/my_test/my_test/rec_image/";
               str = QString("test%1").arg(testvalue);
               QString m_tmpname =str;
               m_imagename.append(m_tmpname);
               m_imagename.append(".jpg");
                  QString toDir=m_imagename;
                toDir.replace("\\","/");
               QDir *createfile     = new QDir;
                bool exist = createfile->exists(toDir);
               QFile::copy(sourceDir, toDir);
                 testvalue=testvalue+1;
               }
                 if(testvalue<3)
                 {
                 QFile file1("/home/hanlifu/my_test/my_test/rec_image/test1.jpg");
                 if(!file1.open(QIODevice::ReadOnly))
                  QMessageBox::about(NULL, "warning", "请换张图片");
                 else
              QMessageBox::about(NULL, "congratulations", "可以开始认证了");
                 }
}
void renlianrenzheng::nextFrame()
{
    face_cascade.load(face_cascade_name);
  //  std::vector<Rect> faces;
//    camera = new QCamera;
  //  camera>>frame;
  //  view_finder->show();//????????????
   //     camera->setViewfinder(view_finder);
    //     camera->start(); //????????
    capture >> frame;
    capture >> yuanshi;
 //   qImg2 =QImage((const unsigned char*)(frame.data),
 //               frame.cols, frame.rows,
 //               frame.cols*frame.channels(),
 //               QImage::Format_RGB888);
        Mat frame_gray;
        cvtColor(frame, frame_gray, CV_BGR2GRAY);
        equalizeHist(frame_gray, frame_gray);
        face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
        int m = 0;
       for (int i = 0; i < faces.size(); i++){
           Point center(faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5);
         ellipse(frame, center, Size(faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);
           temp = yuanshi(Rect(faces[i].x , faces[i].y, faces[i].width, faces[i].height));
   //        imshow(window_name1, temp);
        }
           if(frame.channels()==3)                             //3 channels color image
           {

              cv::cvtColor(frame,frame,CV_BGR2RGB);
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols, frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_RGB888);
           }
           else if(frame.channels()==1)                    //grayscale image
           {
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols,frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_Indexed8);
           }
           else
           {
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols,frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_RGB888);
           }
        ui->label->setPixmap(QPixmap::fromImage(qImg));
    }
// }
void renlianrenzheng::on_pushButton_4_clicked()
{
    face_cascade.load(face_cascade_name);
  //  camera = new QCamera;
   // QSize display_label_szie = ui.display_label->size();
   //    view_finder->setMinimumSize(display_label_szie);
        if (capture.isOpened())
                capture.release();     //decide if capture is already opened; if so,close it
            capture.open(0);           //open the default camera
            if (capture.isOpened())
            {
               // rate= capture.get(CV_CAP_PROP_FPS);
             //  std::vector<Rect> faces;

              //  view_finder->show();//????????????
              //      camera->setViewfinder(view_finder);
                 //    camera->start(); //?????????
                //      camera>>frame;
                capture >> frame;
               // cv::cvtColor(frame,frame,CV_BGR2RGB);
             //   qImg2 =QImage((const unsigned char*)(frame.data),
            //                frame.cols, frame.rows,
           //                 frame.cols*frame.channels(),
           //                 QImage::Format_RGB888);
               capture >> yuanshi;
                    Mat frame_gray;
                    cvtColor(frame, frame_gray, CV_BGR2GRAY);
                 equalizeHist(frame_gray, frame_gray);
                   face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
                    int m = 0;
                    for (int i = 0; i < faces.size(); i++){
                       Point center(faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5);
                     ellipse(frame, center, Size(faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);
                         temp = yuanshi(Rect(faces[i].x , faces[i].y, faces[i].width, faces[i].height));
                       //  if(faces.size()>0)
          //              imshow(window_name1, temp);
                    }
                        if(frame.channels()==3)                             //3 channels color image
                        {

                           cv::cvtColor(frame,frame,CV_BGR2RGB);
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols, frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_RGB888);
                        }
                        else if(frame.channels()==1)                    //grayscale image
                        {
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols,frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_Indexed8);
                        }
                        else
                        {
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols,frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_RGB888);
                        }

                    ui->label->setPixmap(QPixmap::fromImage(qImg));
              timer = new QTimer(this);
               timer->setInterval(0);   //set timer match with FPS
             connect(timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
//           if(testvalue<2)
 //           renlianrenzheng::saveImage();
  //        QFile file1("/home/hanlifu/my_test/my_test/rec_image/test1.jpg");
  //        if(!file1.open(QIODevice::ReadOnly))
   //         QMessageBox::about(NULL, "warning", "请调整姿势，正对摄像头");
   //       else
    //        QMessageBox::about(NULL, "congratulations", "可以开始认证了");
              timer->start();
                }
}
void renlianrenzheng::saveImage()
{
    if(faces.size()>0)
 {
            QString str;
            QMessageBox m_asksavebox(QMessageBox::Question, "Ask", "Save or not?",
                QMessageBox::Yes | QMessageBox::No, NULL);
            if (m_asksavebox.exec() == QMessageBox::Yes)
            {
                str = QString("test%1").arg(testvalue);
                QString m_tmpname =str;
                QString m_imagename = "/home/hanlifu/my_test/my_test/rec_image/";
                m_imagename.append(m_tmpname);
                m_imagename.append(".jpg");
                QPixmap *m_savepixmap = new QPixmap(qImg.width(), qImg.height());
                *m_savepixmap = QPixmap::fromImage(qImg);
                bool m_flag = m_savepixmap->save(m_imagename);
                testvalue=testvalue+1;
                delete m_savepixmap;
            }
    }
    if(testvalue<3)
    {QFile file1("/home/hanlifu/my_test/my_test/rec_image/test1.jpg");
        if(!file1.open(QIODevice::ReadOnly))
            ui->label_8->setText("warning:请调整姿势，正对摄像头");
        else
        ui->label_8->setText("congratulations:可以开始认证了");
        }
}

void renlianrenzheng::on_pushButton_5_clicked()
{
    if(testvalue<2)
   renlianrenzheng::saveImage();
}
