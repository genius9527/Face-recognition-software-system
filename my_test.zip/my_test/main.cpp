#include "my_test.h"
#include"zhuyemian.h"
#include "login.h"
//#include <Windows.h>
//#include <QtGui>
#include <QtWidgets/QApplication>
int main(int argc, char *argv[])
{ //string path=''/home/hanlifu/my_test/my_test/014.jpg'';
	QApplication a(argc, argv);
zhuyemian w;
w.setWindowTitle("zhuyemian");
w.show();
	return a.exec();
}
