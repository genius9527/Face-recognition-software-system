#ifndef RENLIANRENZHENG_H
#define RENLIANRENZHENG_H

#include <QDialog>
// #include "ui_renlianrenzheng.h"
#include <QProcess>
#include <QPushButton>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QPixmap>
#include <QFile>
#include <QImage>
#include <QTimer>
#include <QMessageBox>
#include <QDir>
#include <QDateTime>
#include <QFileDialog>
#include<string>
#include"cv.h"
#include "cxcore.h"
#include "highgui.h"
#include"opencv2/opencv.hpp"
#include<stdio.h>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>  // Gaussian Blur
#include <opencv2/core/core.hpp>        // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/highgui/highgui.hpp>  // OpenCV window I/O
#include "opencv2/objdetect/objdetect.hpp"//人脸识别的接口
using namespace cv;//必须加入,否则无法检找到OPENCV的各个函数
using namespace std;
namespace Ui {
class renlianrenzheng;
}

class renlianrenzheng : public QDialog
{
    Q_OBJECT

public:
    explicit renlianrenzheng(QWidget *parent = 0);
    ~renlianrenzheng();
public:
    //QPushButton *capture_butn;
    //QPushButton *save_butn;
    //QPushButton *exit_butn;
    //QCamera *camera;
    //QCameraViewfinder *view_finder;
    //QCameraImageCapture *camera_image_capture;
    static int testvalue;
    QTimer *timer;
    cv::VideoCapture capture;
    QImage qimage;  //q开头表示Qt的图像格式
   // cv::Mat cvframe;
     QImage qImg;
      QImage qImg2;
      int savetupian=0;
      std::vector<Rect> faces;
    void m_Initialdisplaylabel();
private slots:

 //  void on_pushButton_clicked();
    void nextFrame();
    void on_pushButton_2_clicked();

    double on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();
    void saveImage();

    void on_pushButton_5_clicked();

private:
    Ui::renlianrenzheng *ui;
    cv::Mat frame;
    cv::Mat yuanshi;
    cv::Mat mimage;
    cv::Mat mimage2;
  //   cv::Mat tupian;
     cv::Mat temp;
    QImage  image;
    QImage  m_img;
  //  std::vector<Rect> faces;
    double rate;
    CascadeClassifier face_cascade;
  //  zhuyemian *zym=new zhuyemian;
    string face_cascade_name = "/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_alt.xml";
    QProcess *proces;
};

#endif // RENLIANRENZHENG_H
