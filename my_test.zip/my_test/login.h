#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include<QFile>
#include<QString>
#include<QTextStream>
#include<QStringList>
#include<QObject>
#include<QDebug>
#include<iostream>
#include"my_test.h"
//#include"zhuyemian.h"
class QLineEdit;
class QLabel;
class QPushButton;
namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = 0);
    ~login();
    int m;
    int n;
    QByteArray line;
    void enterControlInterface();
private slots:
    void on_loginButton_clicked();

   // void on_closeButton_clicked();
    void enableloginButton();
private:
    Ui::login *ui;
    my_test *zhuce1=new my_test;

};

#endif // LOGIN_H
