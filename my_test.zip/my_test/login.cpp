#include "login.h"
#include "ui_login.h"
#include <QMessageBox>
QString usernumber;
login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    setWindowTitle(tr("登陆界面"));


    ui->loginButton->setDefault(true);
    ui->loginButton->setEnabled(false);

    connect(ui->userNameEdit, SIGNAL(textChanged(QString)),
            this, SLOT(enableloginButton()));
    connect(ui->passwordEdit, SIGNAL(textChanged(QString)),
            this, SLOT(enableloginButton()));
  connect(ui->closeButton,SIGNAL(clicked()),this,SLOT(close()));
}

login::~login()
{
    delete ui;
}

void login::on_loginButton_clicked()
{QString usern = ui->userNameEdit->text();
    QString pssw=ui->passwordEdit->text();
    int length1 = usern.length();
    int length2 = pssw.length();
   // ui->passwordEdit->setText(usern);
    //ui->passlabel->setText(pssw);
    QFile file("/home/hanlifu/my_test/my_test/user.txt");
  //  QFile file("in.txt");
  //  QString y="hanlifu";
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    while(!file.atEnd()) {
         line = file.readLine();
         QString str(line);
       str = str.trimmed();
     //  qDebug()<< str <<endl;
        m=str.indexOf(usern,5);
        n=str.indexOf(pssw,25);
       if((m>0)&&(n>0)&&(length1==10)&&(length2==10))
        {   usernumber= str.mid(0,5);
           break;
           }
      //  printf("%d",m);
  }
   if((m>0)&&(n>0)&&(length1==10)&&(length2==10))
  {   enterControlInterface();
  //  qDebug()<<usernumber<<endl;
    }
  else
      QMessageBox::about(this,tr("warning"),tr("the password or username is wrong"));
    //if(ui->userNameEdit->text() == tr("w")&& pssw == tr("123"))
   // {
    //      enterControlInterface();
    //}
   // else if(ui->userNameEdit->text() == tr("bzrobot")&& pssw == tr("robot"))
   // {
   //     enterControlInterface();
  //  }
    /*else if(ui->userNameEdit->text() == tr("bzrobot")&& pssw == tr("robot"))
    {
        enterControlInterface();
    }*/
   // else
    //    QMessageBox::about(this,tr("warning"),tr("the password or username is wrong"));

}

//void login::on_closeButton_clicked()
//{

//}
void login::enableloginButton()
{
    bool enable(!ui->userNameEdit->text().isEmpty() && !ui->passwordEdit->text().isEmpty());
    ui->loginButton->setEnabled(enable);
}
void login::enterControlInterface()
{
  QMessageBox::about(this,tr("right"),tr("you are now entering"));
     ui->userNameEdit->clear();
     ui->passwordEdit->clear();
  this->hide();
  zhuce1->show();
   //  close();
}

