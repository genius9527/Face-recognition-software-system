#include "zhuyemian.h"
#include "ui_zhuyemian.h"

zhuyemian::zhuyemian(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::zhuyemian)
{
    ui->setupUi(this);
}

zhuyemian::~zhuyemian()
{
    delete ui;
}

void zhuyemian::on_pushButton_clicked()
{
    this->hide();
    zhuceyanzheng->show();
    zhuceyanzheng->exec();
    this->show();
  //  zhuce->show();
}

void zhuyemian::on_pushButton_2_clicked()
{
      this->hide();
      renzheng->show();
      renzheng->exec();
      this->show();
}
