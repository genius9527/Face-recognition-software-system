/********************************************************************************
** Form generated from reading UI file 'my_test.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MY_TEST_H
#define UI_MY_TEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_my_testClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_4;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QLabel *display_label;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout;
    QLabel *display_label2;
    QSpacerItem *verticalSpacer;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *capture_butn;
    QPushButton *save_butn;
    QPushButton *openImage_butn;
    QPushButton *exit_butn;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *my_testClass)
    {
        if (my_testClass->objectName().isEmpty())
            my_testClass->setObjectName(QStringLiteral("my_testClass"));
        my_testClass->resize(957, 654);
        centralWidget = new QWidget(my_testClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_4 = new QGridLayout(centralWidget);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setMinimumSize(QSize(500, 500));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        display_label = new QLabel(groupBox);
        display_label->setObjectName(QStringLiteral("display_label"));
        display_label->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(display_label->sizePolicy().hasHeightForWidth());
        display_label->setSizePolicy(sizePolicy);
        display_label->setMinimumSize(QSize(600, 500));
        display_label->setMaximumSize(QSize(1000000, 1000000));
        display_label->setSizeIncrement(QSize(5, 5));
        display_label->setFocusPolicy(Qt::ClickFocus);
        display_label->setAutoFillBackground(false);
        display_label->setFrameShape(QFrame::NoFrame);
        display_label->setTextFormat(Qt::RichText);
        display_label->setScaledContents(true);
        display_label->setAlignment(Qt::AlignCenter);
        display_label->setWordWrap(true);

        gridLayout_2->addWidget(display_label, 0, 0, 1, 1);


        gridLayout_4->addWidget(groupBox, 0, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout = new QGridLayout(groupBox_2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        display_label2 = new QLabel(groupBox_2);
        display_label2->setObjectName(QStringLiteral("display_label2"));
        sizePolicy.setHeightForWidth(display_label2->sizePolicy().hasHeightForWidth());
        display_label2->setSizePolicy(sizePolicy);
        display_label2->setMinimumSize(QSize(200, 200));
        display_label2->setMaximumSize(QSize(400, 400));
        display_label2->setAutoFillBackground(false);
        display_label2->setFrameShape(QFrame::NoFrame);

        gridLayout->addWidget(display_label2, 0, 0, 1, 1);


        verticalLayout_2->addWidget(groupBox_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_3 = new QGridLayout(groupBox_3);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        capture_butn = new QPushButton(groupBox_3);
        capture_butn->setObjectName(QStringLiteral("capture_butn"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(capture_butn->sizePolicy().hasHeightForWidth());
        capture_butn->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(capture_butn);

        save_butn = new QPushButton(groupBox_3);
        save_butn->setObjectName(QStringLiteral("save_butn"));
        sizePolicy1.setHeightForWidth(save_butn->sizePolicy().hasHeightForWidth());
        save_butn->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(save_butn);


        verticalLayout->addLayout(horizontalLayout);

        openImage_butn = new QPushButton(groupBox_3);
        openImage_butn->setObjectName(QStringLiteral("openImage_butn"));
        sizePolicy1.setHeightForWidth(openImage_butn->sizePolicy().hasHeightForWidth());
        openImage_butn->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(openImage_butn);

        exit_butn = new QPushButton(groupBox_3);
        exit_butn->setObjectName(QStringLiteral("exit_butn"));
        sizePolicy1.setHeightForWidth(exit_butn->sizePolicy().hasHeightForWidth());
        exit_butn->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(exit_butn);


        gridLayout_3->addLayout(verticalLayout, 0, 0, 1, 1);


        verticalLayout_2->addWidget(groupBox_3);


        gridLayout_4->addLayout(verticalLayout_2, 0, 1, 1, 1);

        my_testClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(my_testClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 957, 26));
        my_testClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(my_testClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        my_testClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(my_testClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        my_testClass->setStatusBar(statusBar);

        retranslateUi(my_testClass);

        QMetaObject::connectSlotsByName(my_testClass);
    } // setupUi

    void retranslateUi(QMainWindow *my_testClass)
    {
        my_testClass->setWindowTitle(QApplication::translate("my_testClass", "my_test", 0));
        groupBox->setTitle(QApplication::translate("my_testClass", "\350\247\206\351\242\221\346\230\276\347\244\272\347\252\227\345\217\243", 0));
        display_label->setText(QString());
        groupBox_2->setTitle(QApplication::translate("my_testClass", "\346\210\252\345\233\276\351\242\204\350\247\210\347\252\227\345\217\243", 0));
        display_label2->setText(QString());
        groupBox_3->setTitle(QApplication::translate("my_testClass", "\346\216\247\345\210\266\345\217\260", 0));
        capture_butn->setText(QApplication::translate("my_testClass", "\346\211\223\345\274\200\346\221\204\345\203\217\345\244\264", 0));
        save_butn->setText(QApplication::translate("my_testClass", "\346\213\215\346\221\204", 0));
        openImage_butn->setText(QApplication::translate("my_testClass", "\346\211\223\345\274\200\346\234\254\345\234\260\345\233\276\345\203\217", 0));
        exit_butn->setText(QApplication::translate("my_testClass", "\351\200\200\345\207\272", 0));
    } // retranslateUi

};

namespace Ui {
    class my_testClass: public Ui_my_testClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MY_TEST_H
