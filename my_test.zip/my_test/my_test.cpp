#include "my_test.h"
// #include "login.h"
//#include "ui_my_test.h"
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>  // Gaussian Blur
#include <opencv2/core/core.hpp>        // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/highgui/highgui.hpp>  // OpenCV window I/O
#include "opencv2/objdetect/objdetect.hpp"//???????????
#include<QString>
#include<QFile>
#include<QDir>
extern QString usernumber;
using namespace cv;//????????,????????????OPENCV?????????
using namespace std;
//string window_name = "hanshuai";
//#include "ui_my_test.h"
//CascadeClassifier face_cascade;
//string face_cascade_name = "D://opencv3.0.0//opencv//build//etc//haarcascades//haarcascade_frontalface_alt.xml";
int my_test::testvalue=1;
//string face_cascade_name = "D://opencv3.0.0//opencv//build//etc//haarcascades//haarcascade_frontalface_alt.xml";
//CascadeClassifier face_cascade;
//string window_name = "renlianjiance";
string window_name1 = "renlianjiance";
string window_name2 = "yuanshituxiang";
my_test::my_test(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    connect(ui.capture_butn, SIGNAL(clicked()), this, SLOT(captureImage()));
    connect(ui.save_butn, SIGNAL(clicked()), this, SLOT(saveImage()));
    connect(ui.exit_butn, SIGNAL(clicked()), this, SLOT(close()));
  //   connect(ui.exit_butn,SIGNAL(clicked()),this,SLOT(close()));
    connect(this, SIGNAL(m_sizechanged()), this, SLOT(m_adjustViewfiderSize()));
    connect(ui.openImage_butn, SIGNAL(clicked()), this, SLOT(m_openImage()));
  //  camera = new QCamera;
  //  view_finder = new QCameraViewfinder(ui.display_label);//?????????????

}

//void detectAndDisplay(Mat frame){
  //  std::vector<Rect> faces;
    //Mat frame_gray;

   // cvtColor(frame, frame_gray, CV_BGR2GRAY);
    //equalizeHist(frame_gray, frame_gray);

    //face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));

    //for (int i = 0; i < faces.size(); i++){
      //  Point center(faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5);
       // ellipse(frame, center, Size(faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);
    //}


//}
void my_test::nextFrame()
{   face_cascade.load(face_cascade_name);
  //  std::vector<Rect> faces;
//    camera = new QCamera;
  //  camera>>frame;
  //  view_finder->show();//????????????
   //     camera->setViewfinder(view_finder);
    //     camera->start(); //????????
    capture >> frame;
    capture >> yuanshi;
 //   qImg2 =QImage((const unsigned char*)(frame.data),
 //               frame.cols, frame.rows,
 //               frame.cols*frame.channels(),
 //               QImage::Format_RGB888);
        Mat frame_gray;
        cvtColor(frame, frame_gray, CV_BGR2GRAY);
        equalizeHist(frame_gray, frame_gray);
        face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
        int m = 0;
       for (int i = 0; i < faces.size(); i++){
           Point center(faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5);
         ellipse(frame, center, Size(faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);
           temp = yuanshi(Rect(faces[i].x , faces[i].y, faces[i].width, faces[i].height));
   //        imshow(window_name1, temp);
        }
           if(frame.channels()==3)                             //3 channels color image
           {

              cv::cvtColor(frame,frame,CV_BGR2RGB);
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols, frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_RGB888);
           }
           else if(frame.channels()==1)                    //grayscale image
           {
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols,frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_Indexed8);
           }
           else
           {
               qImg =QImage((const unsigned char*)(frame.data),
                           frame.cols,frame.rows,
                           frame.cols*frame.channels(),
                           QImage::Format_RGB888);
           }
        ui.display_label->setPixmap(QPixmap::fromImage(qImg));
    //    QSize display_label_szie = ui.display_label->size();
     //   view_finder->setMinimumSize(display_label_szie);
     //   view_finder->show();//????????????
    //    camera->setViewfinder(view_finder);
    //    camera->start();
     //    imshow(window_name2, frame);
}
my_test::~my_test()
{//delete ui;
}
void my_test::captureImage()
{
    m_Initialdisplaylabel();
    face_cascade.load(face_cascade_name);
  //  camera = new QCamera;
   // QSize display_label_szie = ui.display_label->size();
   //    view_finder->setMinimumSize(display_label_szie);
        if (capture.isOpened())
                capture.release();     //decide if capture is already opened; if so,close it
            capture.open(0);           //open the default camera
            if (capture.isOpened())
            {
               // rate= capture.get(CV_CAP_PROP_FPS);
             //  std::vector<Rect> faces;

              //  view_finder->show();//????????????
              //      camera->setViewfinder(view_finder);
                 //    camera->start(); //?????????
                //      camera>>frame;
                capture >> frame;
               // cv::cvtColor(frame,frame,CV_BGR2RGB);
             //   qImg2 =QImage((const unsigned char*)(frame.data),
            //                frame.cols, frame.rows,
           //                 frame.cols*frame.channels(),
           //                 QImage::Format_RGB888);
               capture >> yuanshi;
                    Mat frame_gray;
                    cvtColor(frame, frame_gray, CV_BGR2GRAY);
                 equalizeHist(frame_gray, frame_gray);
                   face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
                    int m = 0;
                    for (int i = 0; i < faces.size(); i++){
                       Point center(faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5);
                     ellipse(frame, center, Size(faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);
                         temp = yuanshi(Rect(faces[i].x , faces[i].y, faces[i].width, faces[i].height));
                       //  if(faces.size()>0)
          //              imshow(window_name1, temp);
                    }
                        if(frame.channels()==3)                             //3 channels color image
                        {

                           cv::cvtColor(frame,frame,CV_BGR2RGB);
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols, frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_RGB888);
                        }
                        else if(frame.channels()==1)                    //grayscale image
                        {
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols,frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_Indexed8);
                        }
                        else
                        {
                            qImg =QImage((const unsigned char*)(frame.data),
                                        frame.cols,frame.rows,
                                        frame.cols*frame.channels(),
                                        QImage::Format_RGB888);
                        }

                    ui.display_label->setPixmap(QPixmap::fromImage(qImg));

                //    m=m+1;

                //     imshow(window_name2, frame);
              //      QSize display_label_szie = ui.display_label->size();
              //      view_finder->setMinimumSize(display_label_szie);
            //        view_finder->show();//????????????
            //        camera->setViewfinder(view_finder);
          //          camera->start();
              timer = new QTimer(this);
               timer->setInterval(0);   //set timer match with FPS
               connect(timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
              timer->start();
                }
  //  if (!camera)
  //  {
  //      camera = new QCamera;//????camera????
 //   }
 //   Mat frame;
 //  int nTick = 0;
 //  QSize display_label_szie = ui.display_label->size();
 //   view_finder->setMinimumSize(display_label_szie);
   // Mat frame;
  //  nTick = getTickCount();
 //  for(;;)
//{
  //  VideoCapture cap(0);
  //  cap >> frame;

 //   detectAndDisplay(edges);
 //   view_finder->show();//????????????
 //   ui.display_label->setScaledContents(true);
  //  camera->setViewfinder(view_finder);
  //   camera->start(); //?????????
  //   setPixmap(QPixmap::fromImage(frame));
  //   camera>>frame;
    // Mat frame;
    // Mat edges;
    // cap>>frame;
    // QImageimg=Mat2QImage(image);//??mat???????Qimage???
          //   ui->label->setPixmap(QPixmap::fromImage(img));//????????label?????
    // cvtColor(frame, edges, CV_BGR2BGRA);
    // }

}

//???????
void my_test::saveImage()
{
    if(faces.size()>0)
 displayImage(qImg);
    else
        ui.display_label2->clear();
  //  capture.open(0);
//m_Initialdisplaylabel();
      //  capture.release();
//camera->start();
//capture.open(0);
//view_finder->show();//????????????
// camera->setViewfinder(view_finder);
  //  camera_image_capture = new QCameraImageCapture(camera);//???????
 //   camera_image_capture->setCaptureDestination(QCameraImageCapture::CaptureToBuffer); //????????????????
 //   camera->setCaptureMode(QCamera::CaptureStillImage); //?????????????
 //  bool a = camera_image_capture->capture();
 //   bool b = connect(camera_image_capture, SIGNAL(imageCaptured(int, QImage)), this, SLOT(displayImage(int, QImage)));
}

//????????label????????????????
void my_test::displayImage(QImage image)
{    QString str;
    ui.display_label2->setPixmap(QPixmap::
        fromImage(image.scaledToWidth(ui.display_label2->width(), Qt::FastTransformation)));
    QMessageBox m_asksavebox(QMessageBox::Question, "Ask", "Save or not?",
        QMessageBox::Yes | QMessageBox::No, NULL);
    if (m_asksavebox.exec() == QMessageBox::Yes)
    {
        str = QString("test%1").arg(testvalue);
          QString m_tmpname =usernumber;
          QString m_imagename = "/home/hanlifu/my_test/my_test/reg_image/";
           m_imagename.append(m_tmpname);
            m_imagename.append(".jpg");
        QFile file1(m_imagename);
        if(!file1.open(QIODevice::ReadOnly)) {
            QPixmap *m_savepixmap = new QPixmap(image.width(), image.height());
             *m_savepixmap = QPixmap::fromImage(image);
               bool m_flag = m_savepixmap->save(m_imagename);
                testvalue=testvalue+1;
               delete m_savepixmap;
       }
        else
        {   QMessageBox::about(NULL, "warning", "ni yi jing <font color='red'>zhuce</font>"); }
       }
}
  //      str = QString("test%1").arg(testvalue);
 //       QString m_tmpname =usernumber;
  //      QString m_imagename = "/home/hanlifu/my_test/my_test/reg_image/";
  //      m_imagename.append(m_tmpname);
   //     m_imagename.append(".jpg");
   //     QPixmap *m_savepixmap = new QPixmap(image.width(), image.height());
   //     *m_savepixmap = QPixmap::fromImage(image);
   //     bool m_flag = m_savepixmap->save(m_imagename);
   //     testvalue=testvalue+1;
    //    delete m_savepixmap;
  //  }
// }

void my_test::close()
{
  // exit(0);
    this->hide();
    capture.release();
}



//????????��?��????????��?????��???????????
void my_test::resizeEvent(QResizeEvent *event)
{
    int a = 0;
    emit m_sizechanged();
}

//?????��?????��???????????????��????????��????
void my_test::m_adjustViewfiderSize()
{
    QSize display_label_szie = ui.display_label->size();
    // view_finder->resize(display_label_szie);
    update();
}

void my_test::m_openImage()
{   // qDebug() <<usernumber<<endl;
    QString str;
    m_Initialdisplaylabel();
    QString m_imagefile;
    face_cascade.load(face_cascade_name);
    vector<Rect> faces2;
    m_imagefile = QFileDialog::getOpenFileName(this, tr("tupianrenlianjiance"), "",
        tr("Image(*.png *.bmp *.jpg)"));
    std::string str1 = m_imagefile.toStdString();
    mimage=imread(str1);
    temp=imread(str1);
  //  if (m_imagefile.isEmpty())
  //      return;
  //  else{

      //  QImage *m_img = new QImage;
      //  if (!(m_img.load(m_imagefile)))
    //    {
     //       QMessageBox::information(this, tr("??????????"), tr("??????????!"));
           // delete m_img;
     //       return;
    //    }
     //   mimage = cv::Mat(m_img.height(), m_img.width(), CV_8UC3, (void*)m_img.constBits(), m_img.bytesPerLine());
              //  cv::cvtColor(mimage, mimage, CV_BGR2RGB);

        Mat gray;
        cvtColor(temp,gray,CV_BGR2GRAY);
        equalizeHist(gray,gray);
         //   cvtColor(mimage,gray,CV_BGR2GRAY); //ת���ɻҶ�ͼ����Ϊharr�����ӻҶ�ͼ����ȡ
        //    equalizeHist(gray,gray);  //ֱ��ͼ������

             face_cascade.detectMultiScale(mimage, faces2, 1.1, 2, 0 | CV_HAAR_SCALE_IMAGE, Size(30, 30));
         //   face_cascade.detectMultiScale(gray,faces2,1.1,3,0,Size(10,10),Size(100,100));
            for(vector<Rect>::const_iterator iter=faces2.begin();iter!=faces2.end();iter++)
            {
                rectangle(mimage,*iter,Scalar(0,0,255),2,8); //������������
            }
           // cv::cvtColor(mimage,mimage,CV_BGR2RGB);
          //  qImg2 =QImage((const unsigned char*)(mimage.data),
              //          mimage.cols, mimage.rows,
             //           mimage.cols*mimage.channels(),
             //           QImage::Format_RGB888);
             imshow(window_name1,mimage);
              if(faces2.size()>0)
              { QString sourceDir=m_imagefile;
             QString m_imagename = "/home/hanlifu/my_test/my_test/reg_image/";
           m_imagename.append(usernumber);
           m_imagename.append(".jpg");
              QString toDir=m_imagename;
              toDir.replace("\\","/");
              QFile file1(toDir);
              if(!file1.open(QIODevice::ReadOnly)) {
              QDir *createfile     = new QDir;
              bool exist = createfile->exists(toDir);
                QFile::copy(sourceDir, toDir);
                testvalue=testvalue+1;
             }
              else
              {   QMessageBox::about(NULL, "warning", "ni yi jing <font color='red'>zhuce</font>"); }
             }
              //   qDebug()<<"Can't open the file!"<<endl;
    //         if(faces2.size()>0)
     //       { QString sourceDir=m_imagefile;
     //        QString m_imagename = "/home/hanlifu/my_test/my_test/reg_image/";
     //        str = QString("test%1").arg(testvalue);
    //         QString m_tmpname =str;
    //         m_imagename.append(m_tmpname);
     //        m_imagename.append(".jpg");
     //         QString toDir=m_imagename;
    //         toDir.replace("\\","/");
   //          QDir *createfile     = new QDir;
    //         bool exist = createfile->exists(toDir);
    //         QFile::copy(sourceDir, toDir);
       //      testvalue=testvalue+1;
   //          }
     //   int m_display_label_width = ui.display_label->width();
     //   ui.display_label->setScaledContents(false);
     //  ui.display_label->setPixmap(QPixmap::
     //      fromImage(qImg2.scaledToWidth(m_display_label_width, Qt::FastTransformation)));
      //  delete m_img;
 //   }

}

void my_test::m_Initialdisplaylabel()
{

    ui.display_label->clear();
    ui.display_label->setScaledContents(true);
    ui.display_label2->clear();

}
